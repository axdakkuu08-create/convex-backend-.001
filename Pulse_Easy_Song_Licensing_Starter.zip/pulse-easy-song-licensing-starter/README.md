# Pulse — Easy Song Licensing integration starter

This is a **reference package**, not a completed or live Pulse integration.

## Where to upload it

In GitHub, open `axdakkuu08-create/convex-backend-.001`, choose **Add file → Upload files**, and upload the contents of this ZIP on a new branch. Keep it in a separate folder such as `integrations/easy-song-licensing/`. Do not put the C# sample inside `apps/pulse-music-workspace/`; that folder is the browser-based music app, not a .NET service.

## Important compatibility note

The supplied Easy Song Licensing sample is an old .NET Core 2.0 console example. It demonstrates authenticated CRUD operations for **licensee records** (`GET/POST/PATCH /licensees`). It does not demonstrate music-catalogue search, audio streaming, or obtaining a licence for an individual song. The sample's stage URL is not configured here as a production endpoint.

Therefore, uploading this package will only add reference code and documentation. It will **not** activate song licensing in Pulse.

## Before implementing a real integration

1. Obtain current Easy Song Licensing API documentation and confirm which endpoints support song search, quote/rights checks, licence creation, and status lookup.
2. Confirm the correct production base URL and authentication scheme with the provider.
3. Implement provider calls in a server-side Convex action or another trusted backend service. Never put an API token in browser JavaScript or a public config file.
4. Store secrets in the hosting platform's secret/environment settings, not in Git.
5. Add UI only after the provider endpoints, permitted use, and response schema are verified.
6. Test with provider-approved sandbox data before enabling production actions.

## Contents

- `reference-example/` — cleaned source files from the supplied C# sample, excluding generated `bin/` and `obj/` build artifacts.
- `docs/INTEGRATION_PLAN.md` — safe implementation checklist for Pulse.
