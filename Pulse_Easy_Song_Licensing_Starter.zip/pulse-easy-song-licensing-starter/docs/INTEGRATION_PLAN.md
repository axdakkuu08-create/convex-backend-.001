# Pulse integration plan: Easy Song Licensing

## What the provided sample actually covers

The source sample creates an HTTP client with a bearer token and calls `/licensees` to list, create, and patch licensee records. It targets .NET Core 2.0 and uses an old staging URL in its appsettings example. It is not a music discovery or playback API example.

## Required provider confirmation

Do not guess these details. Confirm them from current official provider documentation or support:

- Production API base URL and current supported API version
- Authentication and token lifecycle
- Endpoints and schemas for song/work lookup
- How rights, territories, usage types, durations, and quotes are represented
- How a licence is purchased/created and how its status/document is retrieved
- Rate limits, sandbox availability, error codes, and webhook support

## Proposed Pulse architecture after verification

1. Add a server-side provider module under `apps/pulse-backend/convex/`.
2. Keep provider credentials in server-only environment variables.
3. Validate inputs and restrict operations to authenticated, authorized users.
4. Expose narrowly scoped Convex actions for search/quote/licence operations only if the provider documents these endpoints.
5. Save licence references and status in Convex; do not store card data or unnecessary personal information.
6. Add a Pulse UI that clearly distinguishes discovery/playback from licensing and shows price, rights, territory, and status only when returned by the provider.
7. Add tests using mocked responses, then run sandbox end-to-end tests before production rollout.

## Release gate

Do not mark this integration complete until the official endpoints and terms are confirmed, secrets are configured server-side, automated checks pass, and a sandbox flow is verified. Merely uploading this starter is not an implementation.
