﻿// <copyright file="Program.cs" company="Easy Song Licensing">
// Copyright (c) Easy Song Licensing. All rights reserved.
// </copyright>

namespace EasySong.Example
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.JsonPatch;
    using Microsoft.Extensions.Configuration;

    using Newtonsoft.Json;

    /// <summary>
    /// The program.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// The main.
        /// </summary>
        /// <param name="args">
        /// The args.
        /// </param>
        internal static void Main(string[] args)
        {
            var config = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();

            var baseUrl = new UriBuilder(config["apiUrl"])
            {
                Path = "api/"
            };

            var apiKey = GetApiKey();

            var client = new HttpClient
                             {
                                 BaseAddress = baseUrl.Uri
                             };
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            // Send the example GET
            GetLicensees(client).Wait();
            WaitForContinue();

            // Send the example POST
            var userId = PostLicensee(client).Result;
            WaitForContinue();

            // Send the example PATCH
            PatchLicensee(client, userId).Wait();
            WaitForContinue();
        }

        /// <summary>
        /// Get the API key from console input.
        /// </summary>
        /// <returns>
        /// The api key token.
        /// </returns>
        private static string GetApiKey()
        {
            Console.Write("Copy your API key and paste it here: ");

            // Note: Console.ReadLine has a default max length of 254.
            // Since the tokens being read can have a much greater length, a higher limit is needed.
            // This changes the max limit to be 2048.
            // Increase the limit here if needed
            const int BufferSize = 2048;
            Console.SetIn(new StreamReader(Console.OpenStandardInput(BufferSize)));

            // Read the user input
            return Console.ReadLine();
        }

        /// <summary>
        /// An example GET request.
        /// </summary>
        /// <param name="client">
        /// The http client.
        /// </param>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        private static async Task GetLicensees(HttpClient client)
        {
            Console.WriteLine();
            Console.WriteLine("Performing GET on /licensees...");

            // Get the licensees from the API
            var response = await client.GetAsync("licensees");

            // Serialize to licensee list
            var licensees = await HandleResponseAsync<List<LicenseeContract>>(response);

            // GET failed
            if (licensees == null)
            {
                return;
            }

            // print number of licensees found.
            Console.WriteLine($"Licensees found: {licensees.Count}");

            if (licensees.Count > 0)
            {
                var licensee = licensees.First();
                Console.WriteLine("First licensee: ");
                Console.WriteLine(JsonConvert.SerializeObject(licensee));
            }
        }

        /// <summary>
        /// The post licensee.
        /// </summary>
        /// <param name="client">
        /// The client.
        /// </param>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        private static async Task<Guid> PostLicensee(HttpClient client)
        {
            Console.WriteLine();
            Console.WriteLine("Performing POST on /licensees...");

            // Create new licensee to POST
            var newLicensee = new LicenseeContract
                                  {
                                      FirstName = "Example",
                                      LastName = "Test",
                                      Address = "Test Address",
                                      State = "Minnesota",
                                      City = "Test City",
                                      Zip = "12345",
                                      Country = "United States",
                                      Email = $"test.example{(new Random()).Next(10000)}@test.com",
                                      Phone1 = "123-555-1111",
                                      ExternalLicenseeId = "Test1111"
                                  };

            var json = JsonConvert.SerializeObject(newLicensee);
            Console.WriteLine("Submitting following object:");
            Console.WriteLine(json);

            // Create the HTTP content
            var content = new StringContent(json, Encoding.Default, "application/json");

            // POST the new licensee, await the response
            var response = await client.PostAsync("licensees", content);
            
            if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                // Bad request, display the errors returned
                await HandleBadRequestAsync(response);

                return Guid.Empty;
            }

            // Deserialize the response
            var licensee = await HandleResponseAsync<LicenseeContract>(response);
            
            if (licensee == null || !Guid.TryParse(licensee.Id, out var id))
            {
                // POST failed
                return Guid.Empty;
            }

            Console.WriteLine("Returned licensee:");
            Console.WriteLine(JsonConvert.SerializeObject(licensee));

            // Return the licensee Id to be used during PATCH
            return id;
        }

        /// <summary>
        /// The patch licensee.
        /// </summary>
        /// <param name="client">
        /// The client.
        /// </param>
        /// <param name="licenseeId">
        /// The licensee Id.
        /// </param>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        private static async Task PatchLicensee(HttpClient client, Guid licenseeId)
        {
            // Uses the user id from the POST. Do nothing if it does not exist.
            if (licenseeId == Guid.Empty)
            {
                Console.WriteLine("POST failed, skipping PATCH");
                return;
            }

            Console.WriteLine();
            Console.WriteLine($"Performing PATCH on /licensees/{licenseeId}...");

            // Construct the JSON patch document
            var patchDocument = new JsonPatchDocument<LicenseeContract>();

            // Replace the ZIP field, add Phone2
            patchDocument.Replace(l => l.Zip, "54321");
            patchDocument.Add(l => l.Phone2, "123-555-0001");

            // Serialize to JSON
            var json = JsonConvert.SerializeObject(patchDocument);

            Console.WriteLine("Submitting following patch document:");
            Console.WriteLine(json);

            // Create the request method. Since HttpClient does not automatically support PATCH,
            // it will need to be done using the base Send method.
            var request = new HttpRequestMessage(new HttpMethod("PATCH"), $"licensees/{licenseeId}")
            {
                // Create the HTTP content
                Content = new StringContent(json, Encoding.Default, "application/json")
            };

            // Send the PATCH and wait for a response
            var response = await client.SendAsync(request);

            if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                // Bad request, display the errors returned
                await HandleBadRequestAsync(response);

                return;
            }

            // Deserialize the response
            var licensee = await HandleResponseAsync<LicenseeContract>(response);
            
            if (licensee == null)
            {
                // PATCH failed
                return;
            }

            Console.WriteLine("Returned licensee:");
            Console.WriteLine(JsonConvert.SerializeObject(licensee));
        }

        /// <summary>
        /// Handles the http response and deserializes the JSON the the specified object type.
        /// </summary>
        /// <param name="response">
        /// The response.
        /// </param>
        /// <typeparam name="T">
        /// The object type to deserialize to.
        /// </typeparam>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        private static async Task<T> HandleResponseAsync<T>(HttpResponseMessage response)
        {
            // print the status code returned
            Console.WriteLine($"Response status: {response.StatusCode}");

            if (!response.IsSuccessStatusCode)
            {
                // Did not have a status between 200 and 299.
                Console.WriteLine("Request failed.");
                return default(T);
            }

            // Read the JSON content, deserialize to an object
            var json = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(json);
        }

        /// <summary>
        /// The handle response.
        /// </summary>
        /// <param name="response">
        /// The response.
        /// </param>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        private static async Task<Dictionary<string, string[]>> HandleBadRequestAsync(HttpResponseMessage response)
        {
            if (response.StatusCode != HttpStatusCode.BadRequest)
            {
                throw new Exception("Response is not a bad request");
            }

            // print the status code returned
            Console.WriteLine($"Response status: {response.StatusCode}");

            // Read the content into a dictionary
            var content = await response.Content.ReadAsStringAsync();
            var errors = JsonConvert.DeserializeObject<Dictionary<string, string[]>>(content);

            // display all errors returned
            foreach (var kvp in errors)
            {
                Console.WriteLine(kvp.Key);
                foreach (var err in kvp.Value)
                {
                    Console.WriteLine($"   {err}");
                }
            }

            return errors;
        }

        /// <summary>
        /// Waits for user input before continuing.
        /// </summary>
        private static void WaitForContinue()
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
