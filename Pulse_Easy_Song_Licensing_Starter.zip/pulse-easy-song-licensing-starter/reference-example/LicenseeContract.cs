﻿// <copyright file="LicenseeContract.cs" company="Easy Song Licensing">
//   Copyright (c) 2018 Easy Song Licensing. All rights reserved.
// </copyright>
// <summary>
//   Defines the LicenseeContract type.
// </summary>

namespace EasySong.Example
{
    using System;

    /// <summary>
    /// The licensee contract.
    /// </summary>
    public class LicenseeContract
    {
        /// <summary>
        /// Gets or sets the id
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the external licensee id
        /// </summary>
        public string ExternalLicenseeId { get; set; }

        /// <summary>
        /// Gets or sets the first name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the company name
        /// </summary>
        public string CompanyName { get; set; }

        /// <summary>
        /// Gets or sets the address line
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the city
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Gets or sets the state
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Gets or sets the zip
        /// </summary>
        public string Zip { get; set; }

        /// <summary>
        /// Gets or sets the country
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets the email
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the phone 1
        /// </summary>
        public string Phone1 { get; set; }

        /// <summary>
        /// Gets or sets the phone 2
        /// </summary>
        public string Phone2 { get; set; }

        /// <summary>
        /// Gets or sets the phone 3
        /// </summary>
        public string Phone3 { get; set; }

        /// <summary>
        /// Gets or sets the date added
        /// </summary>
        public DateTime DateAdded { get; set; }
    }
}
